function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function hash(n){const x=Math.sin(n*12.9898)*43758.5453;return x-Math.floor(x);}
function sceneColors(scene){
  const map={
    'sakura-alley':['#f8d9df','#f4c7d4','#7f6b6a','#d9b18f','#8d7b75'],
    'golden-residential':['#ffd99a','#f3b36f','#7a674e','#b69a65','#597b4d'],
    'forest-shrine':['#bfe9dd','#72c5a4','#254c3f','#9f8760','#d9e9b8'],
    'summer-lane':['#8bd5ff','#5fae6c','#315b45','#b9774b','#ead6a0'],
    'blue-meadow':['#56a9ee','#bfe9ff','#5b9b47','#8fd05c','#ffffff'],
    'rainy-lantern':['#182844','#2d4f70','#17202e','#d89b56','#6b809b'],
    'autumn-park':['#ffbf74','#8c6a48','#4f5d3e','#c86b3f','#e5a15a'],
    'night-market':['#071226','#162b48','#111820','#e7a64e','#b33b4d']
  };return map[scene]||map['sakura-alley'];
}

export function createCinematicBackgroundPreview(canvas, variant={sceneId:'sakura-alley',seed:1,axes:{}}){
  const ctx=canvas?.getContext('2d'); if(!ctx)return {destroy(){}};
  let raf=0,t=0,disposed=false;
  const seed=Number(variant.seed)||1;
  const colors=sceneColors(variant.sceneId);
  const motion=variant.axes?.camera||'slow dolly';
  const weather=variant.axes?.weather||'clear';
  const wildlife=variant.axes?.wildlife||'birds';
  const foliage=variant.axes?.foliage||'gentle sway';
  const water=variant.axes?.water||'none';

  function resize(){const d=Math.min(devicePixelRatio||1,1.5),w=Math.max(1,Math.floor(canvas.clientWidth*d)),h=Math.max(1,Math.floor(canvas.clientHeight*d));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}}
  function rr(x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();}
  function drawTree(x,y,s,leaf){ctx.fillStyle='#3c332d';ctx.fillRect(x-s*.06,y-s*.4,s*.12,s*.55);ctx.fillStyle=leaf;for(let i=0;i<7;i++){const ox=(hash(seed+i*7.1)-.5)*s*.8,oy=(hash(seed+i*9.2)-.5)*s*.55;ctx.beginPath();ctx.ellipse(x+ox,y+oy,s*(.18+hash(seed+i)*.12),s*(.15+hash(seed+i*2)*.12),0,0,Math.PI*2);ctx.fill();}}
  function drawBird(x,y,s,phase){ctx.strokeStyle='rgba(20,28,38,.75)';ctx.lineWidth=Math.max(1,s*.04);ctx.beginPath();ctx.arc(x-s*.35,y+Math.sin(phase)*s*.08,s*.35,Math.PI*1.05,Math.PI*1.9);ctx.stroke();ctx.beginPath();ctx.arc(x+s*.35,y+Math.sin(phase+.5)*s*.08,s*.35,Math.PI*1.1,Math.PI*1.95);ctx.stroke();}
  function drawPetal(x,y,s,rot,fill){ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.fillStyle=fill;ctx.beginPath();ctx.ellipse(0,0,s*.55,s*.28,0,0,Math.PI*2);ctx.fill();ctx.restore();}

  function draw(){
    if(disposed)return;resize();const w=canvas.width,h=canvas.height;const d=Math.min(1,devicePixelRatio||1);ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,w,h);
    const tt=t*.001; const cam=(motion==='slow pan'||motion==='gentle orbit'||motion==='parallax drift')?Math.sin(tt*.55):tt*.18; const push=motion==='push-in'?tt*.035:motion==='pull-back'?-tt*.025:0;
    const sky=ctx.createLinearGradient(0,0,0,h*.68);sky.addColorStop(0,colors[0]);sky.addColorStop(.65,colors[1]);sky.addColorStop(1,colors[2]);ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);

    // Animated sky / clouds.
    for(let i=0;i<7;i++){const cx=((hash(seed+i)*w)+((tt*(6+i)*8)%w))%w;const cy=h*(.10+hash(seed+i*3)*.22);ctx.fillStyle='rgba(255,255,255,.16)';ctx.beginPath();ctx.ellipse(cx,cy,w*(.10+hash(seed+i)*.05),h*.025,0,0,Math.PI*2);ctx.fill();}
    const horizon=h*.52;
    ctx.fillStyle=colors[2];ctx.fillRect(0,horizon,w,h-horizon);

    // Distant architecture / path.
    const par=cam*w*.035+push*w*.08;
    ctx.save();ctx.translate(par,0);
    ctx.fillStyle=colors[3];
    for(let i=0;i<10;i++){const x=i*w*.12;const bh=h*(.10+hash(seed+i*5)*.16);ctx.fillRect(x,horizon-bh,w*.105,bh);ctx.fillStyle='rgba(255,255,255,.08)';for(let q=0;q<4;q++)ctx.fillRect(x+w*.018+q*w*.022,horizon-bh*.72,w*.012,h*.018);ctx.fillStyle=colors[3];}
    ctx.restore();

    // Main path / street with perspective motion.
    ctx.fillStyle=variant.sceneId==='blue-meadow'?'#77ad54':variant.sceneId==='forest-shrine'?'#807967':'#a68a6e';
    ctx.beginPath();ctx.moveTo(w*.42,h);ctx.lineTo(w*.58,h);ctx.lineTo(w*.54,horizon);ctx.lineTo(w*.46,horizon);ctx.closePath();ctx.fill();
    for(let i=0;i<8;i++){const z=i/8;const y=horizon+(1-z)*(h-horizon);const width=w*(.04+z*.13);ctx.strokeStyle='rgba(255,255,255,.12)';ctx.lineWidth=Math.max(1,w*.003);ctx.beginPath();ctx.moveTo(w/2-width,y);ctx.lineTo(w/2+width,y);ctx.stroke();}

    // Foreground foliage / trees.
    const sway=foliage==='still'?0:Math.sin(tt*1.5)*w*.006;
    for(let i=0;i<8;i++){const x=(i%2===0?i*w*.16-w*.04:w-i*w*.16+w*.04)+sway;const y=h*(.54+hash(seed+i)*.08);drawTree(x,y,h*(.35+hash(seed+i*2)*.2),colors[4]);}

    // Scene-specific architecture motifs.
    if(variant.sceneId==='sakura-alley'||variant.sceneId==='golden-residential'||variant.sceneId==='summer-lane'){
      ctx.fillStyle='rgba(78,55,44,.85)';for(let i=0;i<5;i++){const x=i*w*.24+w*.02;ctx.fillRect(x,h*.37,w*.014,h*.34);ctx.strokeStyle='rgba(78,55,44,.45)';ctx.beginPath();ctx.moveTo(x,h*.42);ctx.lineTo(x+w*.2,h*.33);ctx.stroke();}
    }
    if(variant.sceneId==='forest-shrine'){
      ctx.fillStyle='#6f3f2e';ctx.fillRect(w*.36,h*.37,w*.03,h*.28);ctx.fillRect(w*.61,h*.37,w*.03,h*.28);ctx.fillStyle='#8f5b36';ctx.fillRect(w*.33,h*.35,w*.34,h*.035);ctx.fillRect(w*.35,h*.30,w*.30,h*.035);
    }
    if(variant.sceneId==='night-market'||variant.sceneId==='rainy-lantern'){
      for(let i=0;i<5;i++){const x=w*(.1+i*.19),y=h*(.38+hash(seed+i)*.12);ctx.fillStyle='rgba(255,190,105,.22)';ctx.beginPath();ctx.arc(x,y,w*.025,0,Math.PI*2);ctx.fill();ctx.fillStyle=colors[3];rr(x-w*.012,y-w*.03,w*.024,w*.06,w*.008);}
    }

    // Water / wet reflections.
    if(water!=='none'||variant.sceneId==='rainy-lantern'){
      ctx.fillStyle='rgba(120,185,210,.12)';ctx.fillRect(w*.1,h*.78,w*.8,h*.08);
      for(let i=0;i<12;i++){const x=w*(.12+hash(seed+i)*.75),y=h*(.78+hash(seed+i*4)*.08);ctx.strokeStyle='rgba(220,240,255,.18)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-w*.025,y);ctx.lineTo(x+w*.025,y);ctx.stroke();}
    }

    // Animated wildlife.
    if(wildlife!=='none')for(let i=0;i<4;i++){const x=((hash(seed+i*4)*w)+(tt*(16+i*6)))%w;const y=h*(.18+hash(seed+i*8)*.18);drawBird(x,y,w*.018,tt*(2+i));}

    // Petals/leaves/rain/dust are independent particles, not image frames.
    const count=weather==='rain'?90:(weather==='petals'||foliage==='petal fall'||variant.sceneId==='sakura-alley'?34:28);
    for(let i=0;i<count;i++){
      const base=hash(seed+i*13.7);const x=(base*w + Math.sin(tt*(.5+i%3)+i)*w*.03)%w;const speed=weather==='rain'?h*(.55+hash(seed+i)*.5):h*(.04+hash(seed+i)*.07);const y=((hash(seed+i*2.2)*h + tt*speed)%h);
      if(weather==='rain'){ctx.strokeStyle='rgba(190,220,255,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-w*.004,y+h*.025);ctx.stroke();}
      else if(weather==='petals'||variant.sceneId==='sakura-alley'){drawPetal(x,y,w*.009,(tt+i)*.8,colors[0]);}
      else if(foliage==='leaf fall'||variant.sceneId==='autumn-park'){drawPetal(x,y,w*.012,(tt+i)*.5,colors[3]);}
      else {ctx.fillStyle='rgba(255,245,210,.25)';ctx.beginPath();ctx.arc(x,y,w*.003,0,Math.PI*2);ctx.fill();}
    }

    // Moving sunlight / atmospheric shafts.
    const lx=w*(.22+.18*Math.sin(tt*.22));const grad=ctx.createRadialGradient(lx,h*.28,0,lx,h*.28,w*.5);grad.addColorStop(0,'rgba(255,235,170,.22)');grad.addColorStop(1,'rgba(255,235,170,0)');ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);

    // Clean output: intentionally no buttons, labels, Pinterest chrome, or baked UI.
    t+=16;raf=requestAnimationFrame(draw);
  }
  draw();
  return {destroy(){disposed=true;cancelAnimationFrame(raf);}};
}
