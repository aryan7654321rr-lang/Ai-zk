import { createCinematicBackgroundPreview } from './cinematicBackground';
import { createCinematicVariant } from '../services/cinematicBackgrounds';

export function createVideoPreview(canvas,variant){
  // The video preview is a clean cinematic render surface. It intentionally draws
  // no editor chrome, search buttons, labels, white panels, or other UI into frames.
  const resolved=variant || createCinematicVariant(Date.now(),'sakura-alley');
  return createCinematicBackgroundPreview(canvas,resolved);
}
