export const CHARACTER_AXES = {
  face: ['soft oval', 'sharp jaw', 'round', 'angular', 'long face', 'compact'],
  hair: ['short cap cut', 'textured crop', 'soft fringe', 'layered medium', 'wavy medium', 'long layered'],
  hairColor: ['black', 'deep brown', 'ash brown', 'silver', 'blue-black', 'warm auburn'],
  eyes: ['calm dark', 'bright round', 'sharp', 'soft almond', 'large expressive', 'focused'],
  eyewear: ['none', 'round glasses', 'square glasses', 'thin frames', 'sport frames'],
  top: ['argyle sweater', 'hoodie', 'jacket', 'overshirt', 'turtleneck', 'fantasy tunic', 'academy uniform'],
  bottoms: ['jeans', 'cargo pants', 'wide trousers', 'slim trousers', 'utility pants', 'fantasy pants'],
  shoes: ['canvas sneakers', 'high-top sneakers', 'boots', 'trail shoes', 'formal shoes'],
  accessory: ['none', 'cap', 'scarf', 'shoulder bag', 'wrist band', 'pendant'],
  palette: ['monochrome', 'cool', 'warm', 'earth', 'midnight', 'pastel'],
  fantasyTrait: ['none', 'fox ears', 'cat ears', 'small horns', 'feathered wings', 'tail'],
  style: ['anime', 'stylized 3D', 'semi-realistic 3D', 'cinematic 3D']
};

export function countCharacterCombinations() {
  return Object.values(CHARACTER_AXES).reduce((n, values) => n * values.length, 1);
}

export function createCharacterVariant(seed = Date.now(), overrides = {}) {
  let state = Math.abs(Number(seed) || 1) >>> 0;
  const next = max => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state % max;
  };
  const character = {};
  for (const [axis, values] of Object.entries(CHARACTER_AXES)) {
    character[axis] = overrides[axis] ?? values[next(values.length)];
  }
  character.id = `nova-char-${Math.abs(state).toString(36)}`;
  character.source = 'NOVA Universal Character System';
  character.outputs = ['game-3d', 'video-anime'];
  return character;
}

export function characterLabel(character) {
  return `${character.style} • ${character.hair} • ${character.top}`;
}
