export const CINEMATIC_SCENES = [
  {id:'sakura-alley',name:'Sakura Lantern Alley',style:'anime-cinematic',time:'spring dusk',weather:'petals',motion:['camera-dolly','petals','lantern-sway','birds','water-reflection'],palette:'soft pink / warm wood'},
  {id:'golden-residential',name:'Golden Residential Street',style:'anime-cinematic',time:'golden hour',weather:'clear',motion:['camera-pan','tree-sway','birds','dust','light-shift'],palette:'amber / green / sky blue'},
  {id:'forest-shrine',name:'Forest Shrine Path',style:'anime-cinematic',time:'late morning',weather:'clear',motion:['camera-dolly','leaf-fall','sun-shafts','birds','mist'],palette:'emerald / cyan / warm stone'},
  {id:'summer-lane',name:'Summer Merchant Lane',style:'anime-cinematic',time:'bright afternoon',weather:'clear',motion:['camera-pan','tree-sway','sign-sway','birds','cloud-drift'],palette:'leaf green / terracotta / blue'},
  {id:'blue-meadow',name:'Blue Sky Meadow',style:'anime-cinematic',time:'summer noon',weather:'clear',motion:['camera-dolly','grass-wave','cloud-drift','birds','pollen'],palette:'sky blue / fresh green / white'},
  {id:'rainy-lantern',name:'Rainy Lantern Street',style:'anime-cinematic',time:'blue hour',weather:'rain',motion:['camera-dolly','rain','puddles','umbrella-passers','lantern-reflection'],palette:'indigo / teal / warm amber'},
  {id:'autumn-park',name:'Autumn Evening Park',style:'anime-cinematic',time:'sunset',weather:'leaves',motion:['camera-pan','leaf-fall','bench-parallax','birds','light-shift'],palette:'orange / olive / rose'},
  {id:'night-market',name:'Quiet Night Market',style:'anime-cinematic',time:'night',weather:'clear',motion:['camera-dolly','lantern-glow','steam','birds','sign-sway'],palette:'navy / red / gold'}
];

export const CINEMATIC_VARIATION_AXES = {
  camera:['slow dolly','slow pan','gentle orbit','push-in','pull-back','parallax drift'],
  time:['dawn','morning','noon','afternoon','golden hour','sunset','blue hour','night'],
  weather:['clear','light mist','petals','leaves','rain','drizzle','snow','wind'],
  sky:['soft clouds','high clouds','sunny','overcast','sunset gradient','moonlit'],
  light:['soft','warm','cool','backlit','rim-lit','dappled','lantern-lit'],
  foreground:['grass','flowers','stone','fence','leaves','rain drops','lanterns'],
  wildlife:['birds','butterflies','none','small birds','distant birds'],
  atmosphere:['pollen','dust','mist','humidity','light shafts','clean air'],
  water:['none','stream shimmer','puddle reflections','pond ripple','wet road'],
  foliage:['still','gentle sway','wind gusts','leaf fall','petal fall'],
  architecture:['wood lane','stone lane','shrine path','residential street','market lane'],
  grade:['pastel anime','clean cel-inspired','soft cinematic','high-key daylight','moody cinematic']
};

export function countCinematicVariations(){
  return Object.values(CINEMATIC_VARIATION_AXES).reduce((n,values)=>n*values.length,1);
}

export function createCinematicVariant(seed=Date.now(), sceneId='sakura-alley'){
  let s=Math.abs(Number(seed)||1)>>>0;
  const pick=(arr)=>{s=(s*1664525+1013904223)>>>0;return arr[s%arr.length]};
  const scene=CINEMATIC_SCENES.find(x=>x.id===sceneId)||CINEMATIC_SCENES[0];
  const axes=Object.fromEntries(Object.entries(CINEMATIC_VARIATION_AXES).map(([k,v])=>[k,pick(v)]));
  return {id:`CB-${s.toString(36).toUpperCase()}`,sceneId:scene.id,scene:scene.name,seed:s,axes,cleanOutput:true,noUiOverlays:true,continuousMotion:true,notASlideshow:true};
}
