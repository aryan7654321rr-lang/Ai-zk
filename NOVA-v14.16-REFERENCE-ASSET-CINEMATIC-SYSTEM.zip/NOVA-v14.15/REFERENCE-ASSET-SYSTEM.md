# NOVA Reference Asset System

This build removes the previous Fantasy / Realistic / Medium asset-selection controls and the one-tap world-part selector from the visible Game Studio UI.

## Supplied references

The six supplied scene images are bundled under `public/reference-scenes/` and the supplied character reference is bundled under `public/reference-characters/`.

They are used as reference inputs, not as repeated video frames.

## Intended production transformation

Reference image -> reference analysis -> environment/character reconstruction -> depth/material/lighting layers -> independent animation -> camera track -> cinematic scene asset.

For Game Studio, the target is a real 3D environment/character package with mobile LOD/streaming. For Video/Anime Studio, the target is a clean cinematic scene with animated characters, camera motion, weather, atmosphere, wildlife and lighting changes.

The app UI now exposes the supplied references directly and removes the old visible asset-quality mode buttons. Quality selection is automatic from device profile and scene requirements.

No reference image is used as a repeated still-frame slideshow.
