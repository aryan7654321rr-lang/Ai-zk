# NOVA Cinematic Background System

This update adds a reusable cinematic scene-background layer for both Game Studio and Video / Anime Studio.

## Design goal

The system is **not a slideshow or a frame-book made from repeated still images**. A selected scene is a continuously animated composition driven by a scene descriptor and a deterministic seed.

Each variant can independently change:

- camera path: dolly, pan, orbit, push-in, pull-back, parallax drift
- time of day
- weather
- sky/cloud behavior
- lighting direction and color
- foreground depth layer
- wildlife/birds
- atmospheric particles
- water/puddle reflections
- foliage movement and falling leaves/petals
- architecture/path motif
- color grade

The current prototype exposes more than **2.1 billion** combinations across those axes.

## Game integration

The selected cinematic background runs as an animated underlay behind the interactive WebGL 3D game preview. The 3D runtime remains interactive and is not replaced by the background.

## Video / Anime integration

The selected scene descriptor feeds the separate cinematic video preview. The render surface intentionally contains no editor UI, search buttons, Pinterest-style chrome, white placeholder panels, or controls baked into the visual output.

## Production path

For a production renderer, the same scene descriptor can drive licensed 3D environment assets, background plates, volumetric effects, animated wildlife, water, weather, and camera tracks. The scene descriptor is therefore the reusable specification rather than a collection of copied source images.

## Rights

The uploaded reference screenshots are treated as visual references only and are not bundled into the application. External assets must be acquired through permitted/licensed methods.
