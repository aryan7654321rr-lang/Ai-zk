# NOVA-X APK build

## Important build fix

This package includes `vite.config.js` with the Vue plugin. The previous GitHub failure happened because Vite was trying to parse `src/App.vue` as plain JavaScript/JSX instead of as a Vue Single File Component.

Upload the contents of this folder to the repository root, or upload the ZIP and use the workflow's ZIP extraction path.

The workflow is `.github/workflows/main.yml`.

## Capacitor Android identity
This project includes `capacitor.config.json` with appId `com.novax.studio`, appName `NOVA-X`, and webDir `dist` so `npx cap add android` can create the Android platform in CI.


## GitHub Actions build requirement
The Android build uses Java 21 because current Capacitor Android tooling targets Java 21.

## Android WebGL preview fix
This build applies an Android hardware-accelerated WebView configuration after Capacitor creates the Android project. It enables hardware acceleration on the Activity/WebView and uses a high-performance WebGL context request so the 3D preview can initialize on compatible Android WebViews.
