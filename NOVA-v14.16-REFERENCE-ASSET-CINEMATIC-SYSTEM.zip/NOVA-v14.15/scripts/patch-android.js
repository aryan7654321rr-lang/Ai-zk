import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const mainActivity = path.join(root, 'android/app/src/main/java/com/novax/studio/MainActivity.java');
const manifest = path.join(root, 'android/app/src/main/AndroidManifest.xml');

fs.mkdirSync(path.dirname(mainActivity), { recursive: true });
fs.writeFileSync(mainActivity, `package com.novax.studio;\n\nimport android.os.Bundle;\nimport android.view.View;\nimport android.view.WindowManager;\nimport android.webkit.WebSettings;\nimport android.webkit.WebView;\n\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(Bundle savedInstanceState) {\n        getWindow().setFlags(\n            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,\n            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED\n        );\n\n        super.onCreate(savedInstanceState);\n\n        WebView webView = getBridge().getWebView();\n        if (webView != null) {\n            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);\n            WebSettings settings = webView.getSettings();\n            settings.setJavaScriptEnabled(true);\n            settings.setDomStorageEnabled(true);\n            settings.setDatabaseEnabled(true);\n            settings.setAllowFileAccess(true);\n            settings.setAllowContentAccess(true);\n            settings.setMediaPlaybackRequiresUserGesture(false);\n            WebView.setWebContentsDebuggingEnabled(false);\n        }\n    }\n}\n`);

if (fs.existsSync(manifest)) {
  let xml = fs.readFileSync(manifest, 'utf8');
  if (xml.includes('<application ')) {
    if (!xml.includes('android:hardwareAccelerated=')) {
      xml = xml.replace('<application ', '<application android:hardwareAccelerated="true" ');
    } else {
      xml = xml.replace(/android:hardwareAccelerated="[^"]*"/, 'android:hardwareAccelerated="true"');
    }
    fs.writeFileSync(manifest, xml);
  }
}
