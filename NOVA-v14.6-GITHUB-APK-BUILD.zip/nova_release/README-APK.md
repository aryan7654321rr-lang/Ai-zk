# NOVA-X GitHub APK build

Put the contents of this folder at the **root of your GitHub repository**. In particular, `.github/workflows/main.yml`, `package.json`, `index.html`, `src/`, and `main.py` must be visible at repository root.

The workflow:
1. checks the project;
2. installs Node dependencies;
3. builds NOVA with Vite;
4. installs Capacitor Android;
5. creates/syncs the Android wrapper;
6. builds a debug APK with Gradle;
7. uploads the APK as a GitHub Actions artifact.

Run it from **Actions → NOVA-X APK Build → Run workflow**.

This is a debug APK build. A release APK/AAB should add Android signing secrets before distribution.
