#!/usr/bin/env python3
"""NOVA build helper used by GitHub Actions or local builds.
Finds the project root, validates package.json, and optionally runs npm commands.
"""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def find_package_root(start: Path) -> Path:
    for p in [start, *start.parents]:
        if (p / "package.json").is_file():
            return p
    raise FileNotFoundError("package.json was not found")


def validate(root: Path) -> None:
    data = json.loads((root / "package.json").read_text())
    if not data.get("scripts", {}).get("build"):
        raise RuntimeError("package.json has no build script")
    if not (root / "index.html").exists():
        raise RuntimeError("index.html is missing")


def run(*args: str, cwd: Path = ROOT) -> None:
    print("$", " ".join(args))
    subprocess.run(args, cwd=cwd, check=True)


def main() -> int:
    root = find_package_root(ROOT)
    validate(root)
    if len(sys.argv) == 1:
        print(root)
        return 0
    if sys.argv[1] == "build":
        run("npm", "install", cwd=root)
        run("npm", "run", "build", cwd=root)
        return 0
    print("Usage: python main.py [build]")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
