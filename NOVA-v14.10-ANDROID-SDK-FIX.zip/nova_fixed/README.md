# NOVA v14.2 — Full World + Simple Mobile Preview

This version keeps the interface simple while expanding the Game Studio into a one-tap world builder.

## What is included
- Full starter-world manifest: terrain, nature, roads, hero, cute creatures, NPCs, cars, and mobile cinematic lighting.
- One-tap **Add everything**.
- One-tap `+` / `−` controls for individual world parts.
- Real-time WebGL 3D preview canvas (not a 2D game mockup).
- Automatic preview wake/sleep with IntersectionObserver to reduce phone GPU/battery use.
- Low-end Android remains the default target: small texture budget, limited active lights, short shadow range, streaming-first quality.
- Separate automatic Video Preview; it remains independent from the Game Renderer.
- Online source catalog is license-aware. The included catalog points to CC0 sources such as Quaternius and Kenney; NOVA must still use permitted download methods and should not scrape sites or redistribute restricted assets.

## Online asset sources used for the catalog
- Quaternius Stylized Nature MegaKit: CC0, glTF/FBX/OBJ, Unity URP implementation available.
- Quaternius Cars Pack: CC0, 8 car models.
- Kenney Nature Kit: CC0 3D nature assets.
- Kenney 3D Road Tiles: CC0 road assets.

The app does not bundle third-party packs into this ZIP. This keeps the download small and avoids redistributing assets unnecessarily. The runtime asset resolver is designed to acquire permitted assets and convert them into NOVA mobile variants.

## Quality strategy
Keep the hero and nearby objects detailed; reduce invisible/far work first. Use compressed textures, mipmaps, LODs, streaming, limited dynamic lights, short shadow distance, and mobile-friendly materials. The preview is deliberately lightweight because it runs on the same low-end phone.

## Run
`npm install`
`npm run dev`

The project is a Vue/Vite source prototype. A native production runtime/authorized asset connector is still required to load external Unity-compatible packages directly on-device.


## v14.2 Fantasy High Visuals
The default world preset is now Fantasy High Visuals / Mobile Optimized. It uses license-aware CC0 source packs for nature, town pieces, characters, fantasy outfits and props, while the renderer keeps low-end Android budgets through atlas textures, LOD, instancing, streaming, limited active lights and camera-priority detail.

The bundled app does not redistribute third-party packs. It records the permitted source URLs and asset-selection metadata so an authorized asset resolver can acquire and convert them.
