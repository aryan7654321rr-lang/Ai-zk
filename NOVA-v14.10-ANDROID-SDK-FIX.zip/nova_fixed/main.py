"""NOVA build preflight.
Run with: python main.py
This checks the files required by the GitHub APK workflow.
"""
from pathlib import Path
import json

root = Path(__file__).resolve().parent
required = ["package.json", "index.html", "vite.config.js", "src/App.vue", ".github/workflows/main.yml"]
missing = [p for p in required if not (root / p).exists()]
if missing:
    raise SystemExit("Missing required files: " + ", ".join(missing))

pkg = json.loads((root / "package.json").read_text())
if "build" not in pkg.get("scripts", {}):
    raise SystemExit("package.json does not define npm run build")

print("NOVA preflight OK")
print("Project:", pkg.get("name"))
print("Build command:", pkg["scripts"]["build"])
