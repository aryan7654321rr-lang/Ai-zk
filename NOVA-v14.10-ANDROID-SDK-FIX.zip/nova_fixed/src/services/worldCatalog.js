const common = (prefix, name, category, icon, mobile, cost, quality, source='NOVA license-aware asset resolver') => ({id:prefix, name, category, icon, source, license:'Verified source required', quality, mobile, cost});

export const WORLD_CATALOG = [
  {id:'terrain',name:'Fantasy terrain + cliffs',category:'world',icon:'⛰',source:'Fantasy asset resolver',license:'Verified source required',quality:'High visual',mobile:'1K + LOD',cost:'small'},
  {id:'nature',name:'Fantasy forest + flowers',category:'nature',icon:'🌲',source:'Fantasy nature packs',license:'Verified source required',quality:'High visual',mobile:'Atlas + LOD',cost:'small'},
  {id:'town',name:'Fantasy town + buildings',category:'world',icon:'🏰',source:'Fantasy modular packs',license:'Verified source required',quality:'High visual',mobile:'Instanced modules',cost:'small'},
  {id:'character',name:'Fantasy hero character',category:'character',icon:'🧙',source:'Fantasy character packs',license:'Verified source required',quality:'Hero-high',mobile:'Hero LODs',cost:'small'},
  {id:'creature',name:'Cute fantasy creatures',category:'creature',icon:'🐾',source:'Fantasy creature packs',license:'Verified source required',quality:'High visual',mobile:'Instanced + LOD',cost:'small'},
  {id:'npc',name:'Fantasy NPCs',category:'npc',icon:'🧑',source:'Fantasy character packs',license:'Verified source required',quality:'High visual',mobile:'Shared rigs',cost:'small'},
  {id:'cars',name:'Fantasy carts + vehicles',category:'vehicle',icon:'🛞',source:'Fantasy vehicle packs',license:'Verified source required',quality:'High visual',mobile:'Instanced',cost:'small'},
  {id:'roads',name:'Fantasy roads + paths',category:'world',icon:'═',source:'Fantasy modular road packs',license:'Verified source required',quality:'High visual',mobile:'Tiled + streamed',cost:'small'},
  {id:'props',name:'Fantasy props + market details',category:'props',icon:'🪄',source:'Fantasy prop packs',license:'Verified source required',quality:'High visual',mobile:'Shared atlas',cost:'small'},
  {id:'lighting',name:'Fantasy mobile cinematic lighting',category:'lighting',icon:'☼',source:'NOVA mobile renderer',license:'Built-in',quality:'High visual',mobile:'Baked + cheap dynamic',cost:'tiny'},
  common('realisticTerrain','Realistic terrain + landscapes','world','⛰','1K/2K LOD terrain','small','High visual'),
  common('realisticNature','Realistic vegetation + rocks','nature','🌳','Atlas + aggressive LOD','small','High visual'),
  common('realisticTown','Realistic buildings + interiors','world','🏙','Modular + streamed','small','High visual'),
  common('realisticCharacter','Realistic hero character','character','🧍','Hero LODs + shared materials','small','Hero-high'),
  common('realisticCreature','Realistic animals + creatures','creature','🦊','Instanced + LOD','small','High visual'),
  common('realisticNpc','Realistic NPCs','npc','👤','Shared rigs/materials','small','High visual'),
  common('realisticCars','Realistic cars + traffic','vehicle','🚗','Instanced + simplified physics','small','High visual'),
  common('realisticRoads','Realistic roads + bridges','world','🛣','Tiled + streamed','small','High visual'),
  common('realisticProps','Realistic props + street detail','props','🧰','Shared atlas','small','High visual'),
  common('realisticLighting','Realistic mobile lighting','lighting','☼','Baked + 1–3 dynamic lights','tiny','High visual'),
  common('mediumTerrain','Medium-high terrain + landscapes','world','⛰','1K LOD','small','Medium-high visual'),
  common('mediumNature','Medium-high vegetation + rocks','nature','🌿','Atlas + LOD','small','Medium-high visual'),
  common('mediumTown','Medium-high buildings','world','🏘','Modular + instanced','small','Medium-high visual'),
  common('mediumCharacter','Medium-high hero character','character','🧍','Hero LODs','small','High visual'),
  common('mediumCreature','Cute creatures','creature','🐾','Instanced + LOD','small','High visual'),
  common('mediumNpc','Medium-high NPCs','npc','🧑','Shared rigs','small','Medium-high visual'),
  common('mediumCars','Medium-high cars','vehicle','🚙','Instanced','small','Medium-high visual'),
  common('mediumRoads','Medium-high roads + paths','world','═','Tiled + streamed','small','Medium-high visual'),
  common('mediumProps','Medium-high world props','props','📦','Shared atlas','small','Medium-high visual'),
  common('mediumLighting','Medium-high mobile lighting','lighting','☼','Baked + 2 dynamic lights','tiny','Medium-high visual')
];
export const DEFAULT_WORLD = ['terrain','nature','town','roads','props','character','creature','npc','cars','lighting'];
export const FANTASY_SOURCE_PACKS = [];
export function getCatalogItem(id){return WORLD_CATALOG.find(x=>x.id===id);}
