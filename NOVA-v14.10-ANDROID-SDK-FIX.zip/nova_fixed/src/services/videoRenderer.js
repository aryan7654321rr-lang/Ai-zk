export const VIDEO_RENDERER = {
  id: 'NOVA-CINEMATIC-VIDEO',
  separateFromGame: true,
  pipeline: [
    'script', 'character-bible', 'world-bible', 'storyboard', 'shot-plan',
    'keyframes', 'animation', 'temporal-consistency', 'camera-compositing',
    'lighting-effects', 'voice', 'dialogue-sync', 'audio', 'shot-qc', 'edit'
  ],
  renderPolicy: {
    renderShortShots: true,
    retryOnlyFailedShots: true,
    cacheReusableReferences: true,
    mobileFriendlyPreview: true,
    finalRenderCanBeOffline: true
  }
};

export function buildVideoRenderPlan({ durationMinutes = 10, shotSeconds = 6 } = {}) {
  const safeMinutes = Math.max(1, Number(durationMinutes) || 10);
  const safeShot = Math.max(2, Math.min(15, Number(shotSeconds) || 6));
  const shots = Math.ceil((safeMinutes * 60) / safeShot);
  return {
    durationMinutes: safeMinutes,
    shotSeconds: safeShot,
    estimatedShots: shots,
    pipeline: [...VIDEO_RENDERER.pipeline],
    rule: 'Render and repair individual shots, then assemble the episode.'
  };
}
