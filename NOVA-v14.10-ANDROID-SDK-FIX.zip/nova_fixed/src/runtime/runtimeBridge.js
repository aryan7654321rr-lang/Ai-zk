/**
 * Contract for the eventual native/Unity-compatible 3D runtime.
 * The web UI never substitutes a 2D renderer for the game.
 */
export const NOVA_3D_RUNTIME = {
  id: 'NOVA-3D-MOBILE-RUNTIME',
  renderer: 'native-or-authorized-webgl-3d',
  requiredFeatures: [
    '3d-meshes', 'pbr-materials', 'skinned-animation', 'physics',
    'camera', 'touch-input', 'lighting', 'shadows', 'streaming', 'lod', 'audio'
  ],
  loadPackage(manifest) {
    if (!manifest || !Array.isArray(manifest.assets)) throw new Error('Invalid NOVA 3D runtime manifest');
    return { accepted: true, assetCount: manifest.assets.length, zones: manifest.zones?.length || 0 };
  }
};
