const VS = `attribute vec3 aPos; attribute vec3 aNormal; uniform mat4 uMVP; uniform mat4 uModel; varying vec3 vN; void main(){vN=mat3(uModel)*aNormal;gl_Position=uMVP*vec4(aPos,1.0);}`;
const FS = `precision mediump float; varying vec3 vN; uniform vec3 uColor; uniform vec3 uLight; void main(){float d=max(dot(normalize(vN),normalize(uLight)),0.0);gl_FragColor=vec4(uColor*(0.35+0.65*d),1.0);}`;

function mat4Mul(a,b){const o=new Float32Array(16);for(let r=0;r<4;r++)for(let c=0;c<4;c++)o[c+r*4]=a[r*4]*b[c]+a[r*4+1]*b[c+4]+a[r*4+2]*b[c+8]+a[r*4+3]*b[c+12];return o;}
function perspective(fovy,aspect,n,f){const t=1/Math.tan(fovy/2),o=new Float32Array(16);o[0]=t/aspect;o[5]=t;o[10]=(f+n)/(n-f);o[11]=-1;o[14]=(2*f*n)/(n-f);return o;}
function lookAt(eye,center,up=[0,1,0]){let z=[eye[0]-center[0],eye[1]-center[1],eye[2]-center[2]];let zl=Math.hypot(...z);z=z.map(v=>v/zl);let x=[up[1]*z[2]-up[2]*z[1],up[2]*z[0]-up[0]*z[2],up[0]*z[1]-up[1]*z[0]];let xl=Math.hypot(...x);x=x.map(v=>v/xl);let y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-(x[0]*eye[0]+x[1]*eye[1]+x[2]*eye[2]),-(y[0]*eye[0]+y[1]*eye[1]+y[2]*eye[2]),-(z[0]*eye[0]+z[1]*eye[1]+z[2]*eye[2]),1]);}
function model(x,y,z,sx,sy,sz){return new Float32Array([sx,0,0,0,0,sy,0,0,0,0,sz,0,x,y,z,1]);}
function cube(gl,prog, mvp, m, color){const p=[-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1,-1,-1,1,1,-1,1,1,1,1,-1,1,1];const n=[0,0,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,0,0,1,0,0,1,0,0,1,-1,0,0,-1,0,0,-1,0,0,-1,0,0,1,0,0,1,0,0,1,0,0,1,0,0,-1,0,0,-1,0,0,-1,0,0,-1,0];const idx=[0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,3,2,6,3,6,7,1,5,6,1,6,2,0,3,7,0,7,4];return drawMesh(gl,prog,mvp,m,color,p,n,idx);}
function drawMesh(gl,prog,mvp,m,color,p,n,idx){const pb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,pb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(p),gl.STREAM_DRAW);const aPos=gl.getAttribLocation(prog,'aPos');gl.enableVertexAttribArray(aPos);gl.vertexAttribPointer(aPos,3,gl.FLOAT,false,0,0);const nb=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,nb);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(n),gl.STREAM_DRAW);const aN=gl.getAttribLocation(prog,'aNormal');gl.enableVertexAttribArray(aN);gl.vertexAttribPointer(aN,3,gl.FLOAT,false,0,0);gl.uniformMatrix4fv(gl.getUniformLocation(prog,'uMVP'),false,mvp);gl.uniformMatrix4fv(gl.getUniformLocation(prog,'uModel'),false,m);gl.uniform3fv(gl.getUniformLocation(prog,'uColor'),color);gl.uniform3fv(gl.getUniformLocation(prog,'uLight'),new Float32Array([-.4,.9,.3]));gl.drawElements(gl.TRIANGLES,idx.length,gl.UNSIGNED_SHORT,0);gl.deleteBuffer(pb);gl.deleteBuffer(nb);}

export function createWorldPreview(canvas, state){
  const gl=canvas.getContext('webgl',{antialias:false,alpha:false,preserveDrawingBuffer:false}); if(!gl) return {destroy(){}};
  const sh=(type,src)=>{const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);return s}; const prog=gl.createProgram();gl.attachShader(prog,sh(gl.VERTEX_SHADER,VS));gl.attachShader(prog,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(prog);gl.useProgram(prog);gl.enable(gl.DEPTH_TEST);
  let raf=0,angle=0,camX=0,camZ=0,dragging=false,lastX=0,lastY=0,lookY=9;
  const down=e=>{dragging=true;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture?.(e.pointerId)};
  const move=e=>{if(!dragging)return;angle+=(e.clientX-lastX)*0.008;lookY=Math.max(3,Math.min(18,lookY-(e.clientY-lastY)*0.04));lastX=e.clientX;lastY=e.clientY};
  const up=e=>{dragging=false;canvas.releasePointerCapture?.(e.pointerId)};
  canvas.style.touchAction='none';canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',up);
  const key=e=>{if(e.key==='ArrowLeft')angle-=0.08;if(e.key==='ArrowRight')angle+=0.08;if(e.key==='ArrowUp')camZ-=0.5;if(e.key==='ArrowDown')camZ+=0.5}; window.addEventListener('keydown',key);
  function resize(){const d=Math.min(window.devicePixelRatio||1,1.25),w=Math.max(1,Math.floor(canvas.clientWidth*d)),h=Math.max(1,Math.floor(canvas.clientHeight*d));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}}
  function render(){resize();gl.clearColor(.025,.05,.075,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const aspect=canvas.width/canvas.height;const P=perspective(1.0,aspect,.1,120);const eye=[Math.sin(angle)*24+camX,lookY,Math.cos(angle)*24+camZ],V=lookAt(eye,[camX,1,camZ]);const VP=mat4Mul(P,V);const add=(m,c)=>cube(gl,prog,mat4Mul(VP,m),m,c);
    add(model(0,-2,0,22,.35,22),[.08,.20,.16]);
    // roads
    for(let i=-3;i<=3;i++) add(model(i*5,-1.5,0,1.15,.18,21),[.10,.11,.12]);
    // buildings / landmarks
    for(let i=0;i<7;i++){const x=-15+i*5; const z=(i%2? -5:4); add(model(x,1,z,1.7,3+(i%3),1.7),[.12+.02*i,.18+.01*i,.24+.01*i]);}
    // trees
    if(state.nature){for(let i=0;i<18;i++){const x=((i*17)%34)-17,z=((i*11)%26)-13; add(model(x,0,z,.45,2.1,.45),[.16,.10,.06]); add(model(x,2.3,z,1.5,1.8,1.5),[.12,.34,.20]);}}
    // hero + NPCs
    if(state.character){add(model(0,.2,2,.55,1.7,.4),[.75,.78,.80]);add(model(0,2.05,2,.48,.48,.48),[.75,.60,.48]);}
    if(state.npc){for(let i=0;i<4;i++){const x=-8+i*5;add(model(x,.2,-3,.4,1.45,.35),[.28,.42,.55]);add(model(x,1.85,-3,.36,.36,.36),[.65,.50,.38]);}}
    if(state.creature){for(let i=0;i<3;i++){const x=5+i*2.5;add(model(x,.15,2,.75,.55,.9),[.55,.72,.78]);add(model(x,1.0,2,.55,.45,.55),[.55,.72,.78]);}}
    if(state.cars){for(let i=0;i<3;i++){add(model(-10+i*8,-.8,8,1.2,.55,2.1),[.30,.42,.52]);}}
    angle+=.0018;raf=requestAnimationFrame(render);
  }
  render();
  return {destroy(){cancelAnimationFrame(raf);canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',up);window.removeEventListener('keydown',key);gl.getExtension('WEBGL_lose_context')?.loseContext();}};
}
