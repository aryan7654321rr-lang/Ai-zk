export const NOVA_RUNTIME_MANIFEST_VERSION = 1;

export function createRuntimeManifest({ device = 'low', assets = [], zones = [] } = {}) {
  return {
    version: NOVA_RUNTIME_MANIFEST_VERSION,
    runtime: 'NOVA-MOBILE-RUNTIME',
    device,
    assets: assets.map(asset => ({
      id: asset.id,
      category: asset.category,
      source: asset.source,
      license: asset.license,
      variant: asset.variant || 'mobile',
      dependencies: asset.dependencies || []
    })),
    zones: zones.map(zone => ({
      id: zone.id,
      bounds: zone.bounds,
      preload: zone.preload || [],
      evict: zone.evict || []
    }))
  };
}
