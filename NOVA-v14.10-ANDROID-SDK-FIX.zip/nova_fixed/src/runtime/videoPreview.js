export function createVideoPreview(canvas){
  const ctx=canvas?.getContext('2d'); if(!ctx) return {destroy(){}};
  let raf=0,t=0;
  function resize(){const d=Math.min(devicePixelRatio||1,1.5),w=Math.max(1,Math.floor(canvas.clientWidth*d)),h=Math.max(1,Math.floor(canvas.clientHeight*d));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}}
  function draw(){resize();const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
    const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,'#07111d');g.addColorStop(.55,'#1b2440');g.addColorStop(1,'#090b13');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
    const horizon=h*.52;ctx.fillStyle='#111827';ctx.fillRect(0,horizon,w,h-horizon);
    ctx.fillStyle='rgba(130,170,255,.14)';for(let i=0;i<7;i++){const x=(i*w/7+t*.02)%w;ctx.beginPath();ctx.arc(x,horizon*.72,Math.max(18,w*.025),0,Math.PI*2);ctx.fill();}
    const x=w*.5+Math.sin(t*.006)*w*.08,y=h*.54;ctx.fillStyle='#d7dbea';ctx.fillRect(x-w*.025,y-h*.16,w*.05,h*.16);ctx.beginPath();ctx.arc(x,y-h*.19,w*.032,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='rgba(255,255,255,.8)';ctx.font=`${Math.max(12,w*.026)}px sans-serif`;ctx.fillText('CINEMATIC SHOT • AUTO PREVIEW',w*.05,h*.1);
    t+=1;raf=requestAnimationFrame(draw);
  } draw(); return {destroy(){cancelAnimationFrame(raf);}};
}
