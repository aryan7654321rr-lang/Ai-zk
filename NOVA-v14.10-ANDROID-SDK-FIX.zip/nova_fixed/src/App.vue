<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
import { DEFAULT_GAME_PROMPT } from './prompts/gamePrompt';
import { DEFAULT_VIDEO_PROMPT } from './prompts/videoPrompt';
import { DEVICE_PROFILES, buildQualityPlan } from './services/mobileQuality';
import { buildVideoRenderPlan } from './services/videoRenderer';
import { WORLD_CATALOG, DEFAULT_WORLD, FANTASY_SOURCE_PACKS, getCatalogItem } from './services/worldCatalog';
import { createWorldPreview } from './runtime/worldPreview';
import { createVideoPreview } from './runtime/videoPreview';

const panel=ref(null), menu=ref(false), notice=ref('NOVA READY');
const device=ref(localStorage.getItem('nova.device')||'low');
const gamePrompt=ref(localStorage.getItem('nova.gamePrompt')||DEFAULT_GAME_PROMPT);
const videoPrompt=ref(localStorage.getItem('nova.videoPrompt')||DEFAULT_VIDEO_PROMPT);
const rendererPlacement=ref(localStorage.getItem('nova.rendererPlacement')||'end');
const showAdvanced=ref(false), gamePreviewOn=ref(false), videoPreviewOn=ref(false), built=ref(false);
const visualMode=ref(localStorage.getItem('nova.visualMode')||'fantasy-high');
const gamePreviewRef=ref(null), videoPreviewRef=ref(null), gameCanvas=ref(null), videoCanvas=ref(null);
const worldItems=ref([...DEFAULT_WORLD]);
const GAME_MODES = {
  'fantasy-high': {label:'Fantasy • High graphics', short:'Fantasy High', desc:'Rich fantasy world, hero detail, creatures and cinematic mobile lighting.', badge:'FANTASY HIGH', catalogKey:'fantasy'},
  'realistic-high': {label:'Realistic • High graphics', short:'Realistic High', desc:'Natural materials, realistic environments, vehicles and grounded lighting.', badge:'REALISTIC HIGH', catalogKey:'realistic'},
  'medium-high': {label:'Medium • High graphics', short:'Medium High', desc:'Strong visual quality with a tighter memory and GPU budget for more phones.', badge:'MEDIUM HIGH', catalogKey:'medium'}
};
const MODE_DEFAULTS = {
  'fantasy-high':['terrain','nature','town','roads','props','character','creature','npc','cars','lighting'],
  'realistic-high':['realisticTerrain','realisticNature','realisticTown','realisticRoads','realisticProps','realisticCharacter','realisticCreature','realisticNpc','realisticCars','realisticLighting'],
  'medium-high':['mediumTerrain','mediumNature','mediumTown','mediumRoads','mediumProps','mediumCharacter','mediumCreature','mediumNpc','mediumCars','mediumLighting']
};
const videoPlan=ref(buildVideoRenderPlan());
const qualityPlan=ref(buildQualityPlan(DEVICE_PROFILES.low));
let observer=null, worldRuntime=null, videoRuntime=null;
const currentProfile=computed(()=>DEVICE_PROFILES[device.value]);
const rendererLabel=computed(()=>({end:'At the end',middle:'After setup',top:'Near the top'}[rendererPlacement.value]));
const worldState=computed(()=>Object.fromEntries(worldItems.value.map(id=>[getCatalogItem(id)?.category||id,true])));
const worldCount=computed(()=>worldItems.value.length);
const selectedCards=computed(()=>worldItems.value.map(getCatalogItem).filter(Boolean));

function open(p){panel.value=p;menu.value=false;showAdvanced.value=false;notice.value=p==='game'?'GAME READY':p==='video'?'VIDEO READY':'IMAGE READY';nextTick(setupObservers)}
function closePanel(){panel.value=null;stopObservers();destroyWorld()}
function save(kind){localStorage.setItem(kind==='game'?'nova.gamePrompt':'nova.videoPrompt',kind==='game'?gamePrompt.value:videoPrompt.value);notice.value='Saved'}
function reset(kind){if(kind==='game')gamePrompt.value=DEFAULT_GAME_PROMPT;else videoPrompt.value=DEFAULT_VIDEO_PROMPT;notice.value='Example loaded'}
function applyGameMode(){worldItems.value=[...MODE_DEFAULTS[visualMode.value]]; qualityPlan.value=buildQualityPlan(currentProfile.value,{mode:visualMode.value}); localStorage.setItem('nova.visualMode',visualMode.value); notice.value=`${GAME_MODES[visualMode.value].short} selected`; nextTick(setupWorld)}
function buildGame(){built.value=true;applyGameMode();notice.value=`${GAME_MODES[visualMode.value].short} world ready`;nextTick(()=>{setupObservers();setupWorld()})}
function prepareVideo(){videoPlan.value=buildVideoRenderPlan({durationMinutes:10,shotSeconds:6});notice.value='Video ready';nextTick(setupObservers)}
function addItem(id){if(!worldItems.value.includes(id)){worldItems.value.push(id);notice.value=`Added ${getCatalogItem(id)?.name||id}`;nextTick(setupWorld)}}
function removeItem(id){if(id==='terrain'||id==='character'||id==='lighting'){notice.value='Core world item — keep it for a working build';return}worldItems.value=worldItems.value.filter(x=>x!==id);notice.value=`Removed ${getCatalogItem(id)?.name||id}`;nextTick(setupWorld)}
function addEverything(){worldItems.value=[...MODE_DEFAULTS[visualMode.value]];built.value=true;notice.value=`${GAME_MODES[visualMode.value].short} world added`;nextTick(()=>{setupObservers();setupWorld()})}
function setPlacement(v){rendererPlacement.value=v;localStorage.setItem('nova.rendererPlacement',v);notice.value=`Preview ${rendererLabel.value.toLowerCase()}`}
function setupObservers(){stopObservers();const els=[];if(panel.value==='game'&&gamePreviewRef.value)els.push(['game',gamePreviewRef.value]);if(panel.value==='video'&&videoPreviewRef.value)els.push(['video',videoPreviewRef.value]);if(!els.length||!('IntersectionObserver'in window))return;observer=new IntersectionObserver(es=>es.forEach(e=>{if(e.target.dataset.renderer==='game')gamePreviewOn.value=e.isIntersecting;if(e.target.dataset.renderer==='video')videoPreviewOn.value=e.isIntersecting;if(e.isIntersecting&&e.target.dataset.renderer==='game')setupWorld()}),{threshold:.18,rootMargin:'0px 0px -8% 0px'});els.forEach(([k,e])=>{e.dataset.renderer=k;observer.observe(e)})}
function stopObservers(){if(observer){observer.disconnect();observer=null}gamePreviewOn.value=false;videoPreviewOn.value=false}
function setupWorld(){if(!gamePreviewOn.value||!gameCanvas.value)return;destroyWorld();worldRuntime=createWorldPreview(gameCanvas.value,worldState.value)}
function destroyWorld(){if(worldRuntime){worldRuntime.destroy();worldRuntime=null}}
function setupVideoPreview(){if(!videoPreviewOn.value||!videoCanvas.value)return;destroyVideoPreview();videoRuntime=createVideoPreview(videoCanvas.value)}
function destroyVideoPreview(){if(videoRuntime){videoRuntime.destroy();videoRuntime=null}}
watch(device,()=>{localStorage.setItem('nova.device',device.value);qualityPlan.value=buildQualityPlan(currentProfile.value)})
watch(gamePreviewOn,on=>{if(on)nextTick(setupWorld);else destroyWorld()})
watch(videoPreviewOn,on=>{if(on)nextTick(setupVideoPreview);else destroyVideoPreview()})
onMounted(()=>{qualityPlan.value=buildQualityPlan(currentProfile.value)})
onBeforeUnmount(()=>{stopObservers();destroyWorld();destroyVideoPreview()})
</script>

<template>
<main class="app-shell">
<header class="topbar"><div class="brand-wrap"><div class="nova-mark">N</div><div class="brand">NOVA</div></div><div class="top-actions"><div class="status">{{notice}}</div><button class="dots" @click="menu=!menu">•••</button></div></header>
<div v-if="menu" class="menu"><button @click="open('image')"><span>IMAGE</span><small>Make a still image</small></button><button @click="open('video')"><span>VIDEO / ANIME</span><small>Make a cinematic video</small></button><button @click="open('game')"><span>GAME</span><small>Build and preview a 3D world</small></button></div>
<section v-if="!panel" class="home"><div class="orbital"><div class="orbital-ring ring-a"></div><div class="orbital-ring ring-b"></div><div class="orbital-line"></div><button class="core" @click="open('game')"><span>N</span><small>NOVA</small></button></div><div class="home-caption">CREATE • PREVIEW • USE</div><div class="showcase-row"><button class="showcase-card active" @click="open('game')"><div class="scene-thumb city-thumb"><span>3D GAME</span></div><strong>GAME</strong><small>Build a world and see it on your phone</small></button><button class="showcase-card" @click="open('video')"><div class="scene-thumb anime-thumb"><span>VIDEO</span></div><strong>VIDEO / ANIME</strong><small>Make a cinematic episode</small></button><button class="showcase-card" @click="open('image')"><div class="scene-thumb image-thumb"><span>IMAGE</span></div><strong>IMAGE</strong><small>Create a still image</small></button></div></section>
<section v-else class="workspace">
<div class="workspace-head"><button class="back" @click="closePanel">←</button><div><div class="eyebrow">NOVA / {{panel.toUpperCase()}}</div><h1>{{panel==='game'?'Game':panel==='video'?'Video / Anime':'Image Studio'}}</h1><p v-if="panel==='game'">Add what you want. NOVA keeps the visible world detailed and the phone workload small.</p><p v-else-if="panel==='video'">Make the episode simply. The cinematic preview wakes itself up when visible.</p><p v-else>Simple still-image workspace.</p></div></div>

<div v-if="panel==='game'" class="simple-layout" :class="`placement-${rendererPlacement}`">
<article class="card build-card"><div class="pill">3D WORLD</div><h2>Build your world</h2><p>Start with the full world or add only what you need. Sources are license-aware and mobile variants are preferred.</p><textarea v-model="gamePrompt"></textarea><div class="simple-actions"><button @click="reset('game')">Use example</button><button class="primary" @click="buildGame">Build world</button></div></article>
<article class="card phone-card"><div class="phone-title"><span>PHONE MODE</span><b>{{currentProfile.label}}</b></div><label class="mode-label">GAME STYLE</label><div class="mode-picker"><button v-for="(mode,key) in GAME_MODES" :key="key" :class="{active:visualMode===key}" @click="visualMode=key;applyGameMode()"><b>{{mode.short}}</b><small>{{mode.desc}}</small></button></div><label class="mode-label">DEVICE</label><select v-model="device"><option value="low">Low-end Android</option><option value="balanced">Balanced Android</option><option value="high">Higher Android</option></select><div class="easy-stats"><span><b>{{currentProfile.targetFps}}</b> FPS</span><span><b>{{currentProfile.textureBudgetMB}}</b> MB</span><span><b>{{currentProfile.maxActiveLights}}</b> lights</span></div><p>High-visual fantasy assets stay detailed near the camera. Atlas textures, LOD, instancing and streaming cut storage and GPU work first.</p><div class="mode-badge">{{GAME_MODES[visualMode].badge}} • MOBILE OPTIMIZED</div></article>

<article class="card world-builder"><div class="renderer-head"><div><span class="pill">WORLD KIT</span><h2>One-tap world parts</h2><p>Tap a card to add it. Tap − to remove it. “Add everything” makes the complete starter world.</p></div><button class="primary compact" @click="addEverything">Add everything</button></div><div class="world-grid"><div v-for="item in WORLD_CATALOG" :key="item.id" class="world-item" :class="{selected:worldItems.includes(item.id)}"><div class="world-icon">{{item.icon}}</div><div class="world-copy"><b>{{item.name}}</b><small>{{item.mobile}} • {{item.cost}} storage</small><small>{{item.source}}</small></div><button class="mini-btn" :aria-label="worldItems.includes(item.id)?'Remove '+item.name:'Add '+item.name" @click="worldItems.includes(item.id)?removeItem(item.id):addItem(item.id)">{{worldItems.includes(item.id)?'−':'+'}}</button></div></div><div class="world-summary"><span>{{worldCount}} parts</span><span>Fantasy high visuals</span><span>Mobile-first optimization</span></div><div class="source-links"><a v-for="pack in FANTASY_SOURCE_PACKS" :key="pack.name" :href="pack.url" target="_blank" rel="noreferrer">{{pack.name}}</a></div></article>

<article ref="gamePreviewRef" class="card auto-renderer" :class="{'renderer-on':gamePreviewOn}"><div class="renderer-head"><div><span class="pill">AUTO 3D PREVIEW</span><h2>See the actual world</h2><p>This is a real WebGL 3D preview surface. It wakes when visible and sleeps when you scroll away.</p></div><span class="auto-state">{{gamePreviewOn?'ON':'SLEEPING'}}</span></div><div class="mini-runtime real-runtime game-interactive"><canvas ref="gameCanvas"></canvas><div class="game-controls"><button data-dir="left">◀</button><button data-dir="forward">▲</button><button data-dir="back">▼</button><button data-dir="right">▶</button></div><div v-if="!gamePreviewOn" class="mini-sleep">Scroll here to start the 3D preview</div><div v-else class="mini-live">LIVE • TOUCH TO LOOK • {{currentProfile.targetFps}} FPS TARGET</div></div><div class="renderer-note"><span>3D runtime preview</span><span>{{worldCount}} world parts</span><span>Mobile lighting</span><span>{{rendererLabel}}</span></div></article>

<article class="card easy-more"><button @click="showAdvanced=!showAdvanced">{{showAdvanced?'Hide':'More'}} settings</button><div v-if="showAdvanced" class="advanced-content"><p>{{GAME_MODES[visualMode].label}} • texture cap {{qualityPlan.textureMaxSize}}px • {{qualityPlan.maxActiveLights}} active lights • {{qualityPlan.shadowDistance}}m shadow range • streaming {{qualityPlan.streaming}}.</p><p>Online asset sources are selected for reuse permission; NOVA should download only through allowed methods.</p><div class="source-links"><a v-for="item in selectedCards.filter(x=>x.url)" :key="item.id" :href="item.url" target="_blank" rel="noreferrer">{{item.name}}</a></div></div></article>
</div>

<div v-if="panel==='video'" class="simple-layout" :class="`placement-${rendererPlacement}`"><article class="card build-card"><div class="pill">VIDEO / ANIME</div><h2>Make your video</h2><p>NOVA breaks the episode into small shots and keeps the cinematic renderer separate from the game renderer.</p><textarea v-model="videoPrompt"></textarea><div class="simple-actions"><button @click="reset('video')">Use example</button><button class="primary" @click="prepareVideo">Prepare video</button></div></article><article class="card phone-card"><div class="phone-title"><span>10-MINUTE EPISODE</span><b>{{videoPlan.estimatedShots}} shots</b></div><div class="easy-stats"><span><b>{{videoPlan.shotSeconds}}s</b> shots</span><span><b>10m</b> total</span><span><b>1</b> final</span></div><p>The phone only previews the current shot. Full cinematic rendering remains a separate pipeline.</p></article><article ref="videoPreviewRef" class="card auto-renderer" :class="{'renderer-on':videoPreviewOn}"><div class="renderer-head"><div><span class="pill">AUTO VIDEO PREVIEW</span><h2>See the finished look</h2><p>It automatically turns on when it reaches the screen and sleeps when you scroll away.</p></div><span class="auto-state">{{videoPreviewOn?'ON':'SLEEPING'}}</span></div><div class="mini-video" :class="{active:videoPreviewOn}"><canvas ref="videoCanvas"></canvas><div v-if="!videoPreviewOn" class="mini-sleep">Scroll here to start the cinematic preview</div></div><div class="renderer-note"><span>Separate video renderer</span><span>{{videoPlan.estimatedShots}} shots</span><span>{{rendererLabel}}</span></div></article></div>

<div v-if="panel==='image'" class="studio-grid"><article class="card wide"><div class="pill">IMAGE</div><h2>Image Studio</h2><div class="image-stage"><div class="image-stage-orb">N</div><div><strong>Describe what you want.</strong><p>The image pipeline stays separate from game and video rendering.</p></div></div></article></div>
<div v-if="panel!=='image'" class="preview-placement card"><span>Preview position</span><select :value="rendererPlacement" @change="setPlacement($event.target.value)"><option value="end">At the end</option><option value="middle">After setup</option><option value="top">Near the top</option></select><small>Automatic by default. The preview wakes only when visible.</small></div>
</section>
</main>
</template>
