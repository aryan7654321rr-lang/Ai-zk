# NOVA-X APK build

## Important build fix

This package includes `vite.config.js` with the Vue plugin. The previous GitHub failure happened because Vite was trying to parse `src/App.vue` as plain JavaScript/JSX instead of as a Vue Single File Component.

Upload the contents of this folder to the repository root, or upload the ZIP and use the workflow's ZIP extraction path.

The workflow is `.github/workflows/main.yml`.

## Capacitor Android identity
This project includes `capacitor.config.json` with appId `com.novax.studio`, appName `NOVA-X`, and webDir `dist` so `npx cap add android` can create the Android platform in CI.
